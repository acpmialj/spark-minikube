#!/bin/bash

# unset variable set by kubernetes
unset SPARK_MASTER_PORT
